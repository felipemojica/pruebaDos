//: Playground - noun: a place where people can play

import UIKit

enum Velocidades : Int{
    
    case Apagado = 0
    case VelocidadBaja = 20
    case VelocidadMedia = 50
    case VelocidadAlta = 120
    


init( velocidadInicial : Velocidades){
    self = .Apagado
}
}


class Auto{
    
    var velocidad = Velocidades()
    convenience init(velocidad: Velocidades){
    self.init (velocidad: Velocidades.Apagado)
}
    func cambioDeVelocidad() -> (actual: Int, VelocidadEnCadena: String){
        
    }
}
